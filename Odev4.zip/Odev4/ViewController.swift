//
//  ViewController.swift
//  Odev4
//
//  Created by Ethem Fatih Hocaoğlu on 16.01.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()


    }


}

