//
//  SayfaY.swift
//  Odev4
//
//  Created by Ethem Fatih Hocaoğlu on 17.01.2023.
//

import UIKit

class SayfaY: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
 
    @IBAction func buttonBasaDon(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)

    }
}
